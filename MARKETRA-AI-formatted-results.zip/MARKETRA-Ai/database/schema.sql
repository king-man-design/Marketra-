-- MARKETRA schema — run this in the Supabase SQL editor.
-- Uses Supabase's built-in Auth (auth.users) instead of a custom users table.

create table if not exists businesses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  business_name text not null,
  industry text,
  description text,
  target_customer text,
  location text,
  monthly_marketing_budget numeric,
  current_goal text,
  current_stage text,
  sales_channels text[],
  created_at timestamptz default now()
);

create table if not exists chat_sessions (
  id uuid primary key default gen_random_uuid(),
  business_id uuid references businesses(id) on delete cascade not null,
  title text default 'New chat',
  created_at timestamptz default now()
);

create table if not exists conversations (
  id uuid primary key default gen_random_uuid(),
  session_id uuid references chat_sessions(id) on delete cascade not null,
  business_id uuid references businesses(id) on delete cascade,
  user_message text,
  ai_response jsonb,
  created_at timestamptz default now()
);

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  business_id uuid references businesses(id) on delete cascade,
  name text not null,
  price numeric,
  cost numeric,
  description text
);

create table if not exists analytics (
  id uuid primary key default gen_random_uuid(),
  business_id uuid references businesses(id) on delete cascade,
  date date not null,
  reach integer default 0,
  clicks integer default 0,
  leads integer default 0,
  sales integer default 0,
  revenue numeric default 0,
  spend numeric default 0
);

create index if not exists idx_sessions_business on chat_sessions(business_id, created_at desc);
create index if not exists idx_conversations_session on conversations(session_id, created_at asc);
create index if not exists idx_analytics_business_date on analytics(business_id, date desc);

-- Row Level Security: each user can only see their own data.
-- The frontend talks to Supabase directly with a public anon key for
-- everything except the actual AI call, so RLS is what keeps one
-- user's businesses/chats private from another's.

alter table businesses enable row level security;
alter table chat_sessions enable row level security;
alter table conversations enable row level security;
alter table products enable row level security;
alter table analytics enable row level security;

drop policy if exists "Users manage their own businesses" on businesses;
create policy "Users manage their own businesses" on businesses
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "Users manage sessions on their own businesses" on chat_sessions;
create policy "Users manage sessions on their own businesses" on chat_sessions
  for all using (
    exists (select 1 from businesses b where b.id = business_id and b.user_id = auth.uid())
  ) with check (
    exists (select 1 from businesses b where b.id = business_id and b.user_id = auth.uid())
  );

drop policy if exists "Users manage conversations in their own sessions" on conversations;
create policy "Users manage conversations in their own sessions" on conversations
  for all using (
    exists (
      select 1 from chat_sessions s
      join businesses b on b.id = s.business_id
      where s.id = session_id and b.user_id = auth.uid()
    )
  ) with check (
    exists (
      select 1 from chat_sessions s
      join businesses b on b.id = s.business_id
      where s.id = session_id and b.user_id = auth.uid()
    )
  );

drop policy if exists "Users manage their own products" on products;
create policy "Users manage their own products" on products
  for all using (
    exists (select 1 from businesses b where b.id = business_id and b.user_id = auth.uid())
  ) with check (
    exists (select 1 from businesses b where b.id = business_id and b.user_id = auth.uid())
  );

drop policy if exists "Users manage their own analytics" on analytics;
create policy "Users manage their own analytics" on analytics
  for all using (
    exists (select 1 from businesses b where b.id = business_id and b.user_id = auth.uid())
  ) with check (
    exists (select 1 from businesses b where b.id = business_id and b.user_id = auth.uid())
  );

-- ---------- SocialCrawl public social profile snapshots ----------
-- SocialCrawl reads public profile/content data; it does not provide a social OAuth connection.
create table if not exists social_accounts (
  id uuid primary key default gen_random_uuid(),
  marketra_user_id uuid references auth.users(id) on delete cascade not null,
  platform text not null,
  handle text not null,
  connection_status text not null default 'connected',
  profile_data jsonb,
  last_sync_at timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Migrate an existing social-account table in place to the provider-neutral snapshot format.
alter table social_accounts add column if not exists platform text;
alter table social_accounts add column if not exists handle text;
alter table social_accounts add column if not exists connection_status text default 'connected';
alter table social_accounts add column if not exists profile_data jsonb;
alter table social_accounts add column if not exists last_sync_at timestamptz;
alter table social_accounts add column if not exists updated_at timestamptz default now();
drop index if exists idx_social_accounts_phyllo_user;
alter table social_accounts drop column if exists phyllo_user_id;
alter table social_accounts drop column if exists phyllo_account_id;
create index if not exists idx_social_accounts_user on social_accounts(marketra_user_id);
create unique index if not exists idx_social_accounts_user_platform_handle on social_accounts(marketra_user_id, platform, handle);
alter table social_accounts enable row level security;
drop policy if exists "Users manage their own social accounts" on social_accounts;
create policy "Users manage their own social accounts" on social_accounts
  for all using (auth.uid() = marketra_user_id) with check (auth.uid() = marketra_user_id);

-- Remove the old provider-specific webhook idempotency table; SocialCrawl calls are synchronous.
drop table if exists webhook_events;

-- ---------- Data integrity constraints ----------
-- Added via ALTER TABLE (not the CREATE TABLE blocks above) so this is
-- safe to re-run even though the tables already exist — each is wrapped
-- to skip quietly if the constraint is already present.

do $$ begin
  alter table businesses add constraint businesses_budget_non_negative
    check (monthly_marketing_budget is null or monthly_marketing_budget >= 0);
exception when duplicate_object then null;
end $$;

do $$ begin
  alter table businesses add constraint businesses_name_not_blank
    check (length(trim(business_name)) > 0);
exception when duplicate_object then null;
end $$;

do $$ begin
  alter table social_accounts add constraint social_accounts_status_valid
    check (connection_status in ('pending', 'connected', 'failed', 'disconnected'));
exception when duplicate_object then null;
end $$;

do $$ begin
  alter table chat_sessions add constraint chat_sessions_title_length
    check (length(title) <= 200);
exception when duplicate_object then null;
end $$;

do $$ begin
  alter table conversations add constraint conversations_message_length
    check (user_message is null or length(user_message) <= 4000);
exception when duplicate_object then null;
end $$;

-- ---------- Marketing recommendations (Priority Actions dashboard) ----------
-- Generated by the AI on request (not on every page load — the frontend
-- caches these and only regenerates when the user taps "Refresh" or none
-- exist yet). Scoped to a business, not a chat session, since these are
-- dashboard-level priorities rather than part of a specific conversation.

create table if not exists marketing_recommendations (
  id uuid primary key default gen_random_uuid(),
  business_id uuid references businesses(id) on delete cascade not null,
  priority text not null,
  problem text not null,
  evidence text,
  recommended_action text not null,
  expected_goal text,
  status text default 'open',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index if not exists idx_recommendations_business on marketing_recommendations(business_id, status, created_at desc);

alter table marketing_recommendations enable row level security;

drop policy if exists "Users manage their own recommendations" on marketing_recommendations;
create policy "Users manage their own recommendations" on marketing_recommendations
  for all using (
    exists (select 1 from businesses b where b.id = business_id and b.user_id = auth.uid())
  ) with check (
    exists (select 1 from businesses b where b.id = business_id and b.user_id = auth.uid())
  );

do $$ begin
  alter table marketing_recommendations add constraint recommendations_priority_valid
    check (priority in ('HIGH', 'MEDIUM', 'OPPORTUNITY'));
exception when duplicate_object then null;
end $$;

do $$ begin
  alter table marketing_recommendations add constraint recommendations_status_valid
    check (status in ('open', 'completed', 'dismissed'));
exception when duplicate_object then null;
end $$;

-- ---------- Recommendation execution options + status (Priority 3) ----------
-- Additive, safe to re-run.

alter table marketing_recommendations add column if not exists execution_options text[] default '{}';

do $$ begin
  alter table marketing_recommendations drop constraint recommendations_status_valid;
exception when undefined_object then null;
end $$;

alter table marketing_recommendations add constraint recommendations_status_valid
  check (status in ('open', 'in_progress', 'completed', 'dismissed'));


-- ---------- Recommendation outcomes / measurement loop ----------
-- Manual outcome capture until platform publishing + analytics APIs are connected.
create table if not exists recommendation_outcomes (
  id uuid primary key default gen_random_uuid(),
  recommendation_id uuid references marketing_recommendations(id) on delete cascade not null,
  business_id uuid references businesses(id) on delete cascade not null,
  metric_name text not null,
  metric_value text,
  result_summary text,
  notes text,
  recorded_at timestamptz default now()
);

create index if not exists idx_recommendation_outcomes_recommendation on recommendation_outcomes(recommendation_id, recorded_at desc);
create index if not exists idx_recommendation_outcomes_business on recommendation_outcomes(business_id, recorded_at desc);

alter table recommendation_outcomes enable row level security;

drop policy if exists "Users manage their own recommendation outcomes" on recommendation_outcomes;
create policy "Users manage their own recommendation outcomes" on recommendation_outcomes
  for all using (
    exists (select 1 from businesses b where b.id = business_id and b.user_id = auth.uid())
  ) with check (
    exists (select 1 from businesses b where b.id = business_id and b.user_id = auth.uid())
  );
